<?php
$servername = "localhost";
$database = "u907982086_d";
$username = "u907982086_k";
$password = "KaranYadav1";
 
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
?>